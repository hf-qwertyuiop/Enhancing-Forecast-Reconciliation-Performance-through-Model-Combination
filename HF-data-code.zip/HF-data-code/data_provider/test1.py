class Dataset_Custom(Dataset):
    def __init__(self, args, root_path, flag='train', size=None,
                 features='S', data_path='ETTh1.csv',
                 target='OT', scale=True, timeenc=0, freq='h', seasonal_patterns=None):
        # size [seq_len, label_len, pred_len]
        self.args = args
        if size is None:
            self.seq_len = 24 * 4 * 4  # 这里是时间序列的长度
            self.label_len = 24 * 4   # 标签的长度
            self.pred_len = 24 * 4    # 预测的长度，即h
        else:
            self.seq_len = size[0]
            self.label_len = size[1]
            self.pred_len = size[2]
        
        # 初始化
        assert flag in ['train', 'val', 'test']
        type_map = {'train': 0, 'val': 1, 'test': 2}
        self.set_type = type_map[flag]

        self.features = features
        self.target = target
        self.scale = scale
        self.timeenc = timeenc
        self.freq = freq
        self.root_path = root_path
        self.data_path = data_path
        self.__read_data__()

    def __read_data__(self):
        self.scaler = StandardScaler()
        df_raw = pd.read_csv(os.path.join(self.root_path, self.data_path))

        # 获取列名并移除日期列
        cols = list(df_raw.columns)
        cols.remove('date')  # 移除'date'列
        df_raw = df_raw[['date'] + cols]  # 将'date'列放在前面

        total_length = len(df_raw)  # 数据总长度
        
        # 测试集大小是pred_len，去掉测试集后的长度
        num_test = self.pred_len
        # 减去测试集数据后的剩余数据
        total_length_without_test = total_length - num_test

        # 计算训练集、验证集的大小
        num_train = int(total_length_without_test * 0.7)  # 70%用于训练
        num_val = int(total_length_without_test * 0.2)    # 20%用于验证

        # 数据的边界分割
        border1s = [0, num_train- self.seq_len, total_length_without_test]  # 数据的起始位置
        border2s = [num_train, num_train + num_val, total_length_without_test]  # 数据的结束位置
        border1 = border1s[self.set_type]  # 当前数据集的起始位置
        border2 = border2s[self.set_type]  # 当前数据集的结束位置

        # 根据选择的特征处理数据
        if self.features == 'M' or self.features == 'MS':
            cols_data = df_raw.columns[1:]  # 去除'date'列后的数据列
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            df_data = df_raw[[self.target]]

        # 数据缩放
        if self.scale:
            train_data = df_data[border1s[0]:border2s[0]]
            self.scaler.fit(train_data.values)
            data = self.scaler.transform(df_data.values)
        else:
            data = df_data.values

        # 时间编码（date features）
        df_stamp = df_raw[['date']][border1:border2]
        df_stamp['date'] = pd.to_datetime(df_stamp.date)
        if self.timeenc == 0:
            df_stamp['month'] = df_stamp.date.apply(lambda row: row.month, 1)
            df_stamp['day'] = df_stamp.date.apply(lambda row: row.day, 1)
            df_stamp['weekday'] = df_stamp.date.apply(lambda row: row.weekday(), 1)
            df_stamp['hour'] = df_stamp.date.apply(lambda row: row.hour, 1)
            data_stamp = df_stamp.drop(['date'], 1).values
        elif self.timeenc == 1:
            data_stamp = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = data_stamp.transpose(1, 0)

        # 按照切分范围获取数据
        self.data_x = data[border1:border2]
        self.data_y = data[border1:border2]

        if self.set_type == 0 and self.args.augmentation_ratio > 0:
            self.data_x, self.data_y, augmentation_tags = run_augmentation_single(self.data_x, self.data_y, self.args)

        self.data_stamp = data_stamp

    def __getitem__(self, index):
        # 分割数据的窗口
        s_begin = index
        s_end = s_begin + self.seq_len
        
        # 标签和预测的范围
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = self.data_x[s_begin:s_end]
        seq_y = self.data_y[r_begin:r_end]
        seq_x_mark = self.data_stamp[s_begin:s_end]
        seq_y_mark = self.data_stamp[r_begin:r_end]

        return seq_x, seq_y, seq_x_mark, seq_y_mark

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def inverse_transform(self, data):
        return self.scaler.inverse_transform(data)
