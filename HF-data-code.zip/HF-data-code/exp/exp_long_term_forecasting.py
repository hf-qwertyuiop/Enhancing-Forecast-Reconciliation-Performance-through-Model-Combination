from data_provider.data_factory import data_provider
from exp.exp_basic import Exp_Basic
from utils.tools import EarlyStopping, adjust_learning_rate, visual
from utils.metrics import metric
import torch
import torch.nn as nn
from torch import optim
import os
import time
import warnings
import numpy as np
from utils.dtw_metric import dtw,accelerated_dtw
from utils.losses import mape_loss, mase_loss, smape_loss
from utils.augmentation import run_augmentation,run_augmentation_single
import pandas as pd
from types import SimpleNamespace
import copy
from torch.utils.data import DataLoader, SubsetRandomSampler
import numpy as np
import random
from sklearn.linear_model import Lasso
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_regression
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import Ridge
from sklearn.linear_model import LassoCV
from sklearn.linear_model import RidgeCV
from sklearn.linear_model import LinearRegression
import sys

warnings.filterwarnings('ignore')

# def compute_Q(var_cov, S, l):
#     # Compute Q, where the block matrix C_ij = H[i, j] * Cov(v_it, v_jt)
#     H = torch.matmul(S.T, S)  # H = S^T * S
#     n_b = len(l)  # Number of bottom nodes (blocks)
    
#     # Compute the starting indices for each block in Q
#     #start_indices = torch.cumsum(torch.tensor([1] + l[:-1]).int(), dim=0) - 1  # Adjusted to 0-based index
#     start_indices = torch.cumsum(torch.cat((torch.tensor([1]), l[:-1])), dim=0)- 1  # Adjusted to 0-based index

#     # print('start_indices')
#     # print(start_indices)
    
#     n1 = var_cov.shape[0]  # Number of rows (and columns) in var_cov
#     Q = torch.zeros((n1, n1), dtype=torch.float32)  # Initialize Q as a zero matrix
    
#     # Loop through the blocks to fill Q
#     for i in range(n_b):
#         for j in range(n_b):
#             row_start = start_indices[i].item()
#             row_end = row_start + l[i].item()
#             col_start = start_indices[j].item()
#             col_end = col_start + l[j].item()
            
#             # Calculate C_ij = H[i, j] * Cov(v_it, v_jt)
#             Q[row_start:row_end, col_start:col_end] = H[i, j] * var_cov[row_start:row_end, col_start:col_end]
    
#     return Q
import numpy as np

def compute_Q(var_cov, S, l):
    """
    Compute Q, where the block matrix C_ij = H[i, j] * Cov(v_it, v_jt).
    
    var_cov: numpy array of shape (N, N), the covariance matrix.
    S: numpy array, the matrix used to compute H.
    l: List or numpy array of the number of elements in each block.
    
    Returns:
    Q: numpy array, the resulting matrix Q.
    """
    # Step 1: Compute H = S^T * S
    H = np.dot(S.T, S)  # H = S^T * S
    n_b = len(l)  # Number of bottom nodes (blocks)
    
    # Step 2: Compute the starting indices for each block in Q
    start_indices = np.cumsum(np.concatenate(([1], l[:-1]))) - 1  # Adjusted to 0-based index
    
    # Step 3: Get the shape of the covariance matrix
    n1 = var_cov.shape[0]  # Number of rows (and columns) in var_cov
    Q = np.zeros((n1, n1), dtype=np.float32)  # Initialize Q as a zero matrix
    
    # Step 4: Loop through the blocks to fill Q
    for i in range(n_b):
        for j in range(n_b):
            row_start = start_indices[i]
            row_end = row_start + l[i]
            col_start = start_indices[j]
            col_end = col_start + l[j]
            
            # Calculate C_ij = H[i, j] * Cov(v_it, v_jt)
            Q[row_start:row_end, col_start:col_end] = H[i, j] * var_cov[row_start:row_end, col_start:col_end]
    
    return Q

# Example usage:
# var_cov: Your covariance matrix (N, N) in numpy
# S: Your matrix in numpy (m, n)
# l: List of block sizes
# Q = compute_Q(var_cov, S, l)


import torch




def compute_Phi(Q, l):
    """
    Compute Phi from Q and l.
    
    Q: numpy array of shape (N, N), the matrix to invert.
    l: List or numpy array that saves the number of candidate forecasts for each bottom node.
    
    Returns:
    Phi: numpy array of shape (len(l), sum(l)), the result matrix.
    """
    n_b = len(l)  # Number of bottom nodes
    total_forecasts = sum(l)  # Total number of candidate forecasts
    
    # Step 1: Create matrix A
    A = np.zeros((n_b, total_forecasts))  # Shape (n_b, sum(l))
    start_indices = np.cumsum(np.concatenate(([1], l[:-1]))) - 1  # Step to compute the starting indices
    print('start_indices')
    print(start_indices)
    
    # Fill A with ones according to l
    for r in range(n_b):
        col_start = start_indices[r]
        col_end = col_start + l[r]
        A[r, col_start:col_end] = 1
    
    # Step 2: Create vector b
    b = np.ones((n_b, 1))  # Shape (n_b, 1)
    
    # Step 3: Compute Q_inv using np.linalg.inv()
    Q_inv = np.linalg.inv(Q)  # Compute the inverse of Q
    
    # Step 4: Compute w
    A_Q_inv_A_T = np.dot(A, np.dot(Q_inv, A.T))  # A @ (Q_inv @ A.T)
    
    # Step 5: Compute (A_Q_inv_A_T)^-1 using np.linalg.inv()
    A_Q_inv_A_T_inv = np.linalg.inv(A_Q_inv_A_T)  # Compute the inverse
    
    w = np.dot(np.dot(Q_inv, A.T), np.dot(A_Q_inv_A_T_inv, b))  # w = Q_inv @ A.T @ (A_Q_inv_A_T_inv @ b)
    
    # Step 6: Form Phi from w
    Phi = np.zeros((n_b, total_forecasts))  # Initialize Phi with zeros
    for r in range(n_b):
        col_start = start_indices[r]
        col_end = col_start + l[r]
        Phi[r, col_start:col_end] = w[col_start:col_end, 0]  # Assign the appropriate values from w to Phi
    
    return Phi, w

def divide_no_nan(a, b):
    """
    a/b where the resulted NaN or Inf are replaced by 0.
    """
    result = a / b
    result[result != result] = .0
    result[result == np.inf] = .0
    return result


def predict_for_one_batch(batch_x,batch_y,label_len,pred_len,model):

    B, seq_len, N = batch_x.shape
                # 调整形状以适应模型输入
    batch_x_reshaped = batch_x.permute(0, 2, 1).reshape(B * N, seq_len, 1)
                # 创建解码器输入，形状为 (B*N, label_len + pred_len, 1)
    dec_inp = torch.zeros(B, label_len + pred_len, N).float()
    dec_inp = torch.cat([batch_y[:, :label_len, :], dec_inp[:, label_len:, :]], dim=1)
    dec_inp = dec_inp.permute(0, 2, 1).reshape(B * N, label_len + pred_len, 1)
                # 通过模型进行预测
    outputs_temp = model(batch_x_reshaped, None, dec_inp, None)
                # 将输出调整回原始形状
    outputs = outputs_temp.reshape(B, N, pred_len).permute(0, 2, 1)

    return outputs


def compute_S_Phi_C(all_errors,S,C,n_b,n_a):
    all_errors = np.concatenate(all_errors, axis=0)   # Shape: (total_H, N)
            # Compute variances for each sequence (N)
    variances = np.var(all_errors, axis=0, ddof=1)  # Shape: (N,)
    
            # Use numpy for the next steps
    var_of_error_base = np.diag(variances)  # Create a diagonal matrix from variances
    print('var_of_error_base')
    print(var_of_error_base)
    var_cov_e_y_c = np.matmul(np.matmul(C, var_of_error_base), C.T)  # C * var_of_error_base * C.T
            # l: Full tensor (converted to numpy array)
    l = np.full((n_b,), n_a + 1, dtype=np.int64)  # NumPy equivalent of torch.full
            # Compute Q using the function compute_Q (which you would need to rewrite in NumPy)
    Q = compute_Q(var_cov_e_y_c, S, l)
        
            # Compute Phi and w using the function compute_Phi (which you would need to rewrite in NumPy)
    Phi, w = compute_Phi(Q, l)
            # Perform matrix multiplications using numpy
    S_Phi = np.matmul(S, Phi)  # (n, k)
    S_Phi_C = torch.tensor(np.matmul(S_Phi, C)).float()   # (n, p)
    return S_Phi_C


def compute_S_Phi_C_using_all_training_data(train_loader,label_len,pred_len,model,S,C,n_b,n_a):
    all_errors=[]
    for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
        #batch_x: shape(b,seq_len,m)
        batch_x = batch_x.float()
                #batch_x: shape(b,lab_len+pre_len,m)
        batch_y = batch_y.float()
        batch_x_mark = batch_x_mark.float()
        batch_y_mark = batch_y_mark.float()
        outputs=predict_for_one_batch(batch_x,batch_y,label_len,pred_len,model)

        outputs = outputs[:, -pred_len:, :]
                    #shape(B,H,n)
        batch_y = batch_y[:, -pred_len:,:]
        shape=outputs.shape
                    #compute variance
        error_base=batch_y-outputs
        e_shape=error_base.shape
                    # Reshape error to (B*H, N) and append to all_errors
        all_errors.append(error_base.reshape(-1, shape[-1]).detach().numpy())
            # Concatenate all errors from all batches along the first dimension
    S_Phi_C=compute_S_Phi_C(all_errors,S,C,n_b,n_a)
    return S_Phi_C




# #compute_S_Phi_C_l2_norm(Q,S,C,self.args.n_b,self.args.n_a,lamda)
# def compute_S_Phi_C_l2_norm(Q,S,C,n_b,n_a,lamda):
#             # Compute Phi and w using the function compute_Phi (which you would need to rewrite in NumPy)
#     k=Q.shape[0]
#     l = np.full((n_b,), n_a + 1, dtype=np.int64)  # NumPy equivalent of torch.full
#     Phi, w = compute_Phi(Q+lamda*np.eye(k), l)
#             # Perform matrix multiplications using numpy
#     S_Phi = np.matmul(S, Phi)  # (n, k)
    
#     S_Phi_C = torch.tensor(np.matmul(S_Phi, C)).float()   # (n, p)
#     return S_Phi_C


def compute_S_Phi_C_using_all_training_data_l2_norm(train_loader,label_len,pred_len,model,S,C,n_b,n_a,lamda):
    all_errors=[]
    for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
        #batch_x: shape(b,seq_len,m)
        batch_x = batch_x.float()
                #batch_x: shape(b,lab_len+pre_len,m)
        batch_y = batch_y.float()
        batch_x_mark = batch_x_mark.float()
        batch_y_mark = batch_y_mark.float()
        outputs=predict_for_one_batch(batch_x,batch_y,label_len,pred_len,model)

        outputs = outputs[:, -pred_len:, :]
                    #shape(B,H,n)
        batch_y = batch_y[:, -pred_len:,:]
        shape=outputs.shape
                    #compute variance
        error_base=batch_y-outputs
        e_shape=error_base.shape
                    # Reshape error to (B*H, N) and append to all_errors
        all_errors.append(error_base.reshape(-1, shape[-1]).detach().numpy())
            # Concatenate all errors from all batches along the first dimension
    all_errors = np.concatenate(all_errors, axis=0)   # Shape: (total_H, N)
            # Compute variances for each sequence (N)
    variances = np.var(all_errors, axis=0, ddof=1)  # Shape: (N,)
    
            # Use numpy for the next steps
    var_of_error_base = np.diag(variances)  # Create a diagonal matrix from variances
    print('var_of_error_base')
    print(var_of_error_base)
    var_cov_e_y_c = np.matmul(np.matmul(C, var_of_error_base), C.T)  # C * var_of_error_base * C.T
            # l: Full tensor (converted to numpy array)
    l = np.full((n_b,), n_a + 1, dtype=np.int64)  # NumPy equivalent of torch.full
            # Compute Q using the function compute_Q (which you would need to rewrite in NumPy)
    Q = compute_Q(var_cov_e_y_c, S, l)

    k=Q.shape[0]
    Phi, w = compute_Phi(Q+lamda*np.eye(k), l)
            # Perform matrix multiplications using numpy
    S_Phi = np.matmul(S, Phi)  # (n, k)
    
    S_Phi_C = torch.tensor(np.matmul(S_Phi, C)).float()   # (n, p)

    #S_Phi_C=compute_S_Phi_C_l2_norm(all_errors,S,C,n_b,n_a,lamda)
    return S_Phi_C


#regression problem formulation for L1 or L2 norm 
def train_weights(train_loader,label_len,pred_len,model,S,C,n_b,n_a,method_option):
    all_preds=[]
    all_true=[]
    for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
        #batch_x: shape(b,seq_len,m)
        batch_x = batch_x.float()
                #batch_x: shape(b,lab_len+pre_len,m)
        batch_y = batch_y.float()
        batch_x_mark = batch_x_mark.float()
        batch_y_mark = batch_y_mark.float()
        outputs=predict_for_one_batch(batch_x,batch_y,label_len,pred_len,model)

        outputs = outputs[:, -pred_len:, :]
                    #shape(B,H,n)
        batch_y = batch_y[:, -pred_len:,:]
        shape=outputs.shape
                    #compute variance
        #error_base=batch_y-outputs
        #e_shape=error_base.shape
                    # Reshape error to (B*H, N) and append to all_errors
        all_preds.append(outputs.detach())
        all_true.append(batch_y.detach())
            # Concatenate all errors from all batches along the first dimension
    all_preds = torch.cat(all_preds,dim=0)   # Shape: (total_B, H,N)
    all_true = torch.cat(all_true, dim=0)   # Shape: (total_B, H,N)

# Avoid in-place operation by creating a new tensor for reconciled outputs
    #             outputs_transposed = outputs.transpose(1, 2)  # Shape: (B, N, H)
    #             recon_outputs = torch.matmul(S_Phi_C, outputs_transposed)  # Shape: (B, N, H)
    #             recon_outputs = recon_outputs.transpose(1, 2)  # Shape: (B, H, N)
    #result= torch.matmul(S_Phi_C.unsqueeze(0).expand(outputs.size(0), -1, -1), outputs_T)
    S=torch.tensor(S).float()
    #C=torch.tensor(C)

    S_expanded = S.unsqueeze(0).expand(all_preds.shape[0], -1, -1)  # Shape: (total_B, n, nb)
    #bottom_up_forecasts:shape(total_B,H,N)
    bottom_up_forecasts=torch.matmul(S_expanded, all_preds[:,:,-n_b:].transpose(1, 2)).transpose(1, 2)
    #new_response:shape(total_B,H,N)
    new_response=all_true-bottom_up_forecasts
    #candidate forecasts
    #C_expanded:(total_B,Num_of_candi,N)
    #remove rows in C, these rows forming direct forecats
    non_zero_count = (C != 0).sum(axis=1)
    mask = (non_zero_count == 1) & (C.sum(axis=1) == 1)
    C_filtered = C[~mask]
    # rows_to_delete = np.arange(0, C.shape[0], n_a + 1)
    # C_filtered = np.delete(C, rows_to_delete, axis=0)
    C_filtered=torch.tensor(C_filtered).float()
    C=torch.tensor(C).float()

    C_fitered_expanded= C_filtered.unsqueeze(0).expand(all_preds.shape[0], -1, -1) 
    #candi_forecasts:(total_B,H,Num_of_candi)
    indirect_forecasts=torch.matmul(C_fitered_expanded,all_preds.transpose(1, 2)).transpose(1, 2)
    #difference between candidate combination forecasts and direct bottom forecasts
    diffs=torch.zeros_like(indirect_forecasts)
    bottom_base_forecasts=all_preds[:,:,-n_b:]
    for i in range(n_b):
        start=i*n_a
        end=(i+1)*n_a
        print(i)
        print('shape1')
        print(indirect_forecasts[:, :, start:end].shape)
        print('shape2')
        print(bottom_base_forecasts[:,:,i].unsqueeze(2).expand(-1, -1, n_a).shape)
        diffs[:,:,start:end]=indirect_forecasts[:,:,start:end]-bottom_base_forecasts[:,:,i].unsqueeze(2).expand(-1, -1, n_a)
    #filter zero elements along axis=2
    B,H,N=new_response.shape
    new_regressors=[]
    new_y=torch.zeros(B*H*N, 1)
    index = 0
    for b in range(B):
        for h in range(H):
            #non_zero_elements = diffs[b, h, :] != 0  # Create a boolean mask for non-zero elements
            # print('zero_elems')
            # print(diffs[b, h, :] == 0 )
            #shape(number_of_indirect_forecasts,)
            filtered_diff = diffs[b, h,:]  # Apply the mask to filter out zeros
            # print('lens')
            # print(len(filtered_diff))
            # Insert each part into a different row
            diff_matrix = torch.zeros(n_b,n_b*n_a)
            for i in range(n_b):
                start_idx = i * n_a
                end_idx = (i + 1) * n_a  # Ending column for each row
                diff_matrix[i, start_idx:end_idx] = filtered_diff[start_idx:end_idx]  # Insert into the row
            #S_diff,shape(n,n_b*n_a)
            S_diff=torch.matmul(S,diff_matrix)
            new_regressors.append(S_diff)
            #Insert the entire vector new_response[b, h, :]
            new_y[index:index + N] = new_response[b, h, :].view(-1, 1)
            index += N


    new_regressors = torch.cat(new_regressors,dim=0)   # Shape: (N*(BH),n_b*n_a)

    #fit linear to model
    new_y=new_y.numpy()
    new_regressors=new_regressors.numpy()
    s=new_y.shape[0]
    print('new_x_y_shape')
    print(new_y.shape)
    print(new_regressors.shape)
    # Select 1% of the data randomly
    sample_size = int(0.1 * s)  # 1% of the data
    # Generate random indices to select 1% of data
    indices = np.random.choice(s, size=sample_size, replace=False)
    # Select corresponding values from new_y and new_regressors
    # new_y = new_y[indices]
    # new_regressors = new_regressors[indices]
    lamda1 = np.linspace(1e-15, 10, 10)
    lamda2 = np.linspace(15, 10000, 10)
    lamdas=np.concatenate([lamda1, lamda2])
    #fit
    if method_option=='L1_norm':
        # Create a Lasso regression model with automatic cross-validation to select alpha
        lasso_cv = LassoCV(alphas=lamdas,cv=5,fit_intercept=False)  # 5-fold cross-validation
        # Train the model
        lasso_cv.fit(new_regressors, new_y)
        weights=lasso_cv.coef_
    elif method_option=='L2_norm':
        ridge_cv = RidgeCV(alphas=lamdas,cv=5,fit_intercept=False)
        ridge_cv.fit(new_regressors, new_y)
        weights=ridge_cv.coef_
        weights=weights.squeeze()
    elif method_option=='ordinary_regression':
        model = LinearRegression(fit_intercept=False)
        model.fit(new_regressors, new_y)
        weights=model.coef_
        weights=weights.squeeze()


    print('weights')
    print(weights)
    #form Phi matrix
    Phi=np.zeros((n_b,n_b*(n_a+1)))
    for i in range(n_b):
        start_indices=i*(n_a+1)
        end_indices=(i+1)*(n_a+1)
        Phi[i,start_indices+1:end_indices]=weights[i*n_a:(i+1)*n_a]
        Phi[i,start_indices]=1-np.sum(weights[i*n_a:(i+1)*n_a])



            # Perform matrix multiplications using numpy
    S_Phi = np.matmul(S, Phi)  # (n, k)
    
    S_Phi_C = torch.tensor(np.matmul(S_Phi, C)).float()   # (n, p)

    #S_Phi_C=compute_S_Phi_C_l2_norm(all_errors,S,C,n_b,n_a,lamda)
    return S_Phi_C

#compute var_cov of prediction errors
def cal_var_cov_errors(train_loader,label_len,pred_len,model):

    all_preds=[]
    all_true=[]
    for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
        #batch_x: shape(b,seq_len,m)
        batch_x = batch_x.float()
                #batch_x: shape(b,lab_len+pre_len,m)
        batch_y = batch_y.float()
        batch_x_mark = batch_x_mark.float()
        batch_y_mark = batch_y_mark.float()
        outputs=predict_for_one_batch(batch_x,batch_y,label_len,pred_len,model)

        outputs = outputs[:, -pred_len:, :]
                    #shape(B,H,n)
        batch_y = batch_y[:, -pred_len:,:]
        shape=outputs.shape
                    #compute variance
        #error_base=batch_y-outputs
        #e_shape=error_base.shape
                    # Reshape error to (B*H, N) and append to all_errors
        all_preds.append(outputs.detach())
        all_true.append(batch_y.detach())
            # Concatenate all errors from all batches along the first dimension
    all_preds = torch.cat(all_preds,dim=0)   # Shape: (total_B, H,N)
    all_true = torch.cat(all_true, dim=0)   # Shape: (total_B, H,N)
    #estimate variance-cov of prediction errors
    total_B, H, N = all_preds.shape
    all_preds_flat = all_preds.view(-1, N)  # Shape: (total_B * H, N)
    all_true_flat = all_true.view(-1, N)    # Shape: (total_B * H, N)
    # Compute the prediction errors
    errors = all_preds_flat - all_true_flat  # Shape: (total_B * H, N)
    # Compute the covariance matrix of the errors (prediction error covariance matrix)
    #cov_matrix_errors = torch.matmul(errors.T, errors) / (errors.shape[0] - 1)
    variances = torch.var(errors, dim=0, unbiased=True)  # Shape: (H, N)
    # Create a diagonal matrix from variances
    cov_matrix_errors = torch.diag_embed(variances)  # Shape: (H, N, N)
    #
    return cov_matrix_errors

#compute map matrix C from base forecasts to combination forecasts
def compute_C_for_comb_partial(S):
    # Get dimensions of S
    n,m = S.shape
    num_of_agg = n - m  # Aggregation rows
    
    # Initialize C matrix
    C = torch.zeros((int(S.sum()), n))
    # print('C-shape')
    # print(C.shape)
    d = 0  # Counter for rows in C
    
    # Iterate over columns of S (i from 0 to m-1)
    for i in range(m):
        # Extract rows where the value is 1 in column i
        rows_with_one = S[S[:, i] == 1, :]
        row_indices = torch.nonzero(S[:, i] == 1).squeeze()  # Get row indices where S[:, i] == 1
        num = row_indices.size(0)  # Number of 1s in column i
        # print('row_indices')
        # print(row_indices)
        # print(torch.nonzero(S[:, i] == 1))
        
        for j in range(num):
            # Set C[d, row_indices[j]] = 1
            C[d, row_indices[j]] = 1
            
            # Find non-zero column indices in the row corresponding to 1
            col_inds = torch.nonzero(rows_with_one[j, :] != 0).squeeze()
            # Exclude the target column i
            col_inds_1 = col_inds[col_inds != i]
            # Adjust indices by adding num_of_agg
            col_inds_1 = col_inds_1 + num_of_agg
            
            # Set corresponding values in C to -1
            for col_ind in col_inds_1:
                C[d, col_ind] = -1
            
            # Increment counter for C's rows
            d += 1
    
    return C

#compute combination weights using bates and gate
import torch

def compute_weights(k, var_cov):
    # Compute the inverse of the variance-covariance matrix
    inv_matrix = torch.inverse(var_cov)
    
    # Print the dimension of the variance-covariance matrix
    # print('dim')
    # print(var_cov.shape)
    
    # Create a column vector of ones with shape (k, 1)
    e = torch.ones((k, 1), dtype=torch.float32)
    
    # Compute the weights
    w = torch.matmul(inv_matrix, e) / (torch.matmul(torch.matmul(e.t(), inv_matrix), e))[0, 0]
    
    return w

#form Phi matrix for comb_partial method, where var_cov_y_c: prediction error var-cov matrix of candidate forecasts
def compute_Phi_comb_partial(S, var_cov_y_c):
    # Model combination
    g = 0  # Start index for the variance-covariance matrix slice
    s = 0  # Start index for the Phi matrix
    m = S.shape[1]  # Number of bottom-leval nodes
    
    # Combination weight matrix (m x sum(S))
    Phi = torch.zeros((m, int(S.sum())), dtype=torch.float32)
    
    for i in range(m):
        #print(i)
        # k: number of forecasts for combination
        #k = torch.sum(S[:, i]).item()
        #
        k = int(S[:, i].sum())
        
        # Get the relevant submatrix of the variance-covariance matrix
        var_cov_slice = var_cov_y_c[g:g + k, g:g + k]
        
        # Compute weights, shape(k,1)
        weights = compute_weights(k, var_cov_slice)
        
        # Update Phi matrix with the computed weights
        Phi[i, s:s + k] = weights.squeeze()  # Flatten the weight to match the row slice
        g += k
        s += k
    
    return Phi





class Exp_HF_Forecast(Exp_Basic):
    def __init__(self, args):
        super(Exp_HF_Forecast, self).__init__(args)

    def _build_model(self):
        model = self.model_dict[self.args.model].Model(self.args).float()

        if self.args.use_multi_gpu and self.args.use_gpu:
            model = nn.DataParallel(model, device_ids=self.args.device_ids)
        return model


#get shuffled training data
    def _get_data_for_training(self, flag):
        # #    def __init__(self, args, root_path, flag='train', size=None,
        #          features='S', data_path='ETTh1.csv',
        #          target='OT', scale=True, timeenc=0, freq='h', seasonal_patterns=None)
        print('self.args')
        print(self.args)
        data_set, data_loader = data_provider(self.args, flag)
        return data_set, data_loader

    def _get_data_for_test(self, flag):
        # #    def __init__(self, args, root_path, flag='train', size=None,
        #          features='S', data_path='ETTh1.csv',
        #          target='OT', scale=True, timeenc=0, freq='h', seasonal_patterns=None)
        #
        original_args = copy.deepcopy(self.args)
        original_args.data='custom_test'
        data_set, data_loader = data_provider(original_args, flag)
        return data_set, data_loader

#get S matrix
    def _get_S_C_matrix(self):
        root_path=self.args.root_path
        S_path=self.args.S_path
        C_path=self.args.C_path
        S = pd.read_csv(os.path.join(root_path,S_path))
        C=pd.read_csv(os.path.join(root_path,C_path))

        return np.array(S.iloc[:,1:]),np.array(C.iloc[:,1:])

        #return torch.tensor(S.iloc[:,1:].values, dtype=torch.float32),torch.tensor(C.iloc[:,1:].values, dtype=torch.float32)



    def _select_optimizer(self):
        model_optim = optim.Adam(self.model.parameters(), lr=self.args.learning_rate)
        return model_optim

    # def _select_criterion(self):
    #     criterion = nn.MSELoss()
    #     return criterion

    def _select_criterion(self, loss_name='SMAPE'):
        if loss_name == 'MSE':
            return nn.MSELoss()
        elif loss_name == 'MAPE':
            return mape_loss()
        elif loss_name == 'MASE':
            return mase_loss()
        elif loss_name == 'SMAPE':
            return smape_loss()

    def vali(self, vali_data, vali_loader):
        total_loss = []
        self.model.eval()
         # print(test_data.shape)
        train_data, train_loader = self._get_data_for_test(flag='train')
        S,C=self._get_S_C_matrix()

        print('S-matrix')
        print(S.shape)
        with torch.no_grad():
            S_Phi_C=compute_S_Phi_C_using_all_training_data(train_loader,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a)


        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(vali_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float()

                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                outputs=predict_for_one_batch(batch_x,batch_y,self.args.label_len,self.args.pred_len,self.model)

                outputs = outputs[:, -self.args.pred_len:, :]
                batch_y = batch_y[:, -self.args.pred_len:, :]
                # #inverse transformation

                #reconcil
                                    #reconciliation: S*\Phi*y_{ct}
                    #reconciliation: S*\Phi*y_{ct}
                outputs_T = outputs.permute(0, 2, 1)  # Shape (B, n, H)
                    #Perform the matrix multiplications in batch using torch.matmul
                    # Now multiply S_Phi_C with batch_y_T (B, n, H)
                result= torch.matmul(S_Phi_C.unsqueeze(0).expand(outputs.size(0), -1, -1), outputs_T)
                recon_outputs=result.permute(0, 2, 1)  # Final shape: (32, 8, 57)


                pred = recon_outputs.detach().cpu()
                true = batch_y.detach().cpu()

                #loss = criterion(pred, true)
                loss=200 * torch.mean(divide_no_nan(torch.abs(recon_outputs - batch_y),torch.abs(recon_outputs.data) + torch.abs(batch_y.data)))

                total_loss.append(loss)
        total_loss = np.average(total_loss)
        self.model.train()
        return total_loss


    def train_nn(self,train_loader,vali_data,vali_loader,S_Phi_C,model_optim,path):
        early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)

        for epoch in range(self.args.train_epochs):
            train_loss = []
            self.model.train()
            epoch_time = time.time()
            #compute Phi using trained model 
            #S_Phi_C=compute_S_Phi_C_using_all_training_data(train_loader_1,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a)


            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
                #iter_count += 1
                model_optim.zero_grad()
                #batch_x: shape(b,seq_len,m)
                batch_x = batch_x.float().to(self.device)
                #batch_x: shape(b,lab_len+pre_len,m)
                batch_y = batch_y.float().to(self.device)


                outputs=predict_for_one_batch(batch_x,batch_y,self.args.label_len,self.args.pred_len,self.model)

                # encoder - decoder

                print('batch_x')
                print(batch_x.shape)

                outputs = outputs[:, -self.args.pred_len:, :]
                    #shape(B,H,n)
                batch_y = batch_y[:, -self.args.pred_len:, :]
                shape=outputs.shape
                #do the reconcilation
                print('batch_y_shape')
                print(batch_y.shape)
                print('output-shape')
                print(outputs.shape)

                # Avoid in-place operation by creating a new tensor for reconciled outputs
                outputs_transposed = outputs.transpose(1, 2)  # Shape: (B, N, H)
                recon_outputs = torch.matmul(S_Phi_C, outputs_transposed)  # Shape: (B, N, H)
                recon_outputs = recon_outputs.transpose(1, 2)  # Shape: (B, H, N)

                print('recon_outputs')
                print(recon_outputs.shape)

                #loss=criterion(batch_x, self.args.frequency, recon_outputs, batch_y, batch_y_mark)
                loss=200 * torch.mean(divide_no_nan(torch.abs(recon_outputs - batch_y),torch.abs(recon_outputs.data) + torch.abs(batch_y.data)))

                print('second-stage-loss')
                print(loss)
                    #loss = criterion(recon_outputs, batch_y)
                train_loss.append(loss.item())

                loss.backward()
                model_optim.step()

            print("second-stage-Epoch: {} cost time: {}".format(epoch + 1, time.time() - epoch_time))
            train_loss = np.average(train_loss)


            vali_loss = self.vali(vali_data, vali_loader)
            #test_loss = self.vali(test_data, test_loader, criterion)

            print("Epoch: {0} | Train Loss: {1:.7f} Vali Loss: {2:.7f}".format(epoch + 1, train_loss, vali_loss))
            early_stopping(vali_loss, self.model, path)
            if early_stopping.early_stop:
                print("Early stopping")
                break
            #adjust_learning_rate(model_optim, epoch + 1, self.args)

        #vali_loss = self.vali(vali_data_1, vali_loader_1, criterion)

        best_model_path = path + '/' + 'checkpoint.pth'
        self.model.load_state_dict(torch.load(best_model_path))

        return self.model,vali_loss


    def train_for_first_stage(self,train_loader,model_optim):
        for epoch in range(self.args.train_epochs):
            #iter_count = 0
            train_loss = []

            self.model.train()
            epoch_time = time.time()
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
            #for batch_x, batch_y, batch_x_mark, batch_y_mark in select_batches:
                #iter_count += 1
                model_optim.zero_grad()
                #batch_x: shape(b,seq_len,m)
                batch_x = batch_x.float().to(self.device)
                #batch_x: shape(b,lab_len+pre_len,m)
                batch_y = batch_y.float().to(self.device)

                # decoder input
                #dec_inp: (b,pred_len,m)
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                #dec_inp: (b,label_len+pred_len,m)
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)


                print('batch_x')
                print(batch_x.shape)
                print('batch_x_mark')
                print(batch_x_mark.shape)
                print('dec_inp')
                print(dec_inp.shape)
                outputs = self.model(batch_x, None, dec_inp, None)
                print('output-shape')
                print(outputs.shape)
                print('batch_y')
                print(batch_y.shape)

                outputs = outputs[:, -self.args.pred_len:, :]
                    #shape(B,H,n)
                batch_y = batch_y[:, -self.args.pred_len:, :]
                batch_y_mark = batch_y_mark[:, -self.args.pred_len:,:].to(self.device)
                shape=outputs.shape
                #loss = criterion(batch_x, self.args.frequency, outputs, batch_y, batch_y_mark)
                loss=200 * torch.mean(divide_no_nan(torch.abs(outputs - batch_y),torch.abs(outputs.data) + torch.abs(batch_y.data)))
                #loss = criterion(outputs, batch_y)
                print('first-stage-loss')
                print(loss)
                    #loss = criterion(recon_outputs, batch_y)
                train_loss.append(loss.item())

                loss.backward()
                model_optim.step()

            print("first-stage-Epoch: {} cost time: {}".format(epoch + 1, time.time() - epoch_time))
            train_loss = np.average(train_loss)

        return self.model



    def test_no_recon(self,setting):
        train_data_1, train_loader_1 = self._get_data_for_test(flag='train')
        vali_data_1, vali_loader_1 = self._get_data_for_test(flag='val')
        test_data_1, test_loader_1 = self._get_data_for_test(flag='test')


        preds=[]
        trues=[]
        all_errors = []
        for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader_1):
            batch_x = batch_x.float()
            batch_y = batch_y.float()
            # num_of_series=batch_x.shape[2]
            outputs=predict_for_one_batch(batch_x,batch_y,self.args.label_len,self.args.pred_len,self.model)
            outputs = outputs[:, -self.args.pred_len:, :]
            batch_y = batch_y[:, -self.args.pred_len:, :]
            shape=outputs.shape

            pred = outputs.detach().cpu().numpy()
            true = batch_y.detach().cpu().numpy()

            preds.append(pred)
            trues.append(true)



        preds = np.concatenate(preds, axis=0)
        trues = np.concatenate(trues, axis=0)
        print('test shape:', preds.shape, trues.shape)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        print('test shape:', preds.shape, trues.shape)
         # result save
        folder_path = './results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)


        mae, mse, rmse, mape, mspe,smape = metric(preds, trues)
        print('mse:{}, mae:{}, rmse:{}, mape:{}, mspe:{}, smape:{}'.format(mse, mae, rmse,mape, mspe,smape))
        # f = open("result_long_term_forecast.txt", 'a')
        # f.write(setting + "  \n")
        # f.write('mse:{}, mae:{}, dtw:{}'.format(mse, mae, dtw))
        # f.write('\n')
        # f.write('\n')
        # f.close()

        return 



    def train(self, setting):
        #get batch data
        #
        train_data, train_loader = self._get_data_for_training(flag='train')
        S,C=self._get_S_C_matrix()
        print('S-matrix')
        print(S.shape)
        print('C-matrix')
        print(C.shape)

        path = os.path.join(self.args.checkpoints, setting)
        if not os.path.exists(path):
            os.makedirs(path)

        time_now = time.time()

        #train_steps = len(train_loader)
        #early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)

        model_optim = self._select_optimizer()
        criterion = self._select_criterion()


        #first stage, smape training without reconcilation
        # 随机抽取 10% 的索引
        # 获取所有批次数据
        all_batches = list(train_loader)
        # 随机选择10%的批次
        select_batches = random.sample(all_batches, int(len(all_batches) * 0.1))

        #first stage: train NN without reconcilation using SMAPE
        #self.model=train_for_first_stage(self,train_loader,model_optim)
        #train_for_first_stage(self,train_loader,model_optim)
        self.model=self.train_for_first_stage(select_batches,model_optim)
        #self.model=self.train_for_first_stage(train_loader,model_optim)


        #compute accuracy on test data using the model trained at first stage

        self.test_no_recon(setting)

        train_data_1, train_loader_1 = self._get_data_for_test(flag='train')
        vali_data_1, vali_loader_1 = self._get_data_for_test(flag='val')
        test_data_1, test_loader_1 = self._get_data_for_test(flag='test')

        #second stage: alternate training for reconcilation
        for i in range(1):
            print('alternate_time')
            print(i+1)
            #compute Phi using trained model 
            S_Phi_C=compute_S_Phi_C_using_all_training_data(train_loader_1,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a)
            #train_nn(self,train_loader,vali_data,vali_loader,S_Phi_C,model_optim)
            self.model,vali_loss=self.train_nn(train_loader_1,vali_data_1,vali_loader_1,S_Phi_C,model_optim,path)

        return self.model

    def test(self, setting, test=0):
        #test_data is an instance of cunstom_dataset()
        preds = []
        trues = []

        train_data_1, train_loader_1 = self._get_data_for_test(flag='train')
        #vali_data_1, vali_loader_1 = self._get_data_for_test(flag='val')
        test_data_1, test_loader_1 = self._get_data_for_test(flag='test')
        S,C=self._get_S_C_matrix()
        print('S-matrix')
        print(S.shape)
        print('C-matrix')
        print(C.shape)
        # print('test_data_shape')
        # print(test_data.shape)
        if test:
            print('loading model')
            self.model.load_state_dict(torch.load(os.path.join('./checkpoints/' + setting, 'checkpoint.pth')))

        #estimate var of each component series


        preds = []
        trues = []
        folder_path = './test_results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        self.model.eval()

        with torch.no_grad():
            # Initialize a container to accumulate errors across batches
            S_Phi_C=compute_S_Phi_C_using_all_training_data(train_loader_1,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a)


        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader_1):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)

                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                outputs=predict_for_one_batch(batch_x,batch_y,self.args.label_len,self.args.pred_len,self.model)

                outputs = outputs[:, -self.args.pred_len:, :]
                batch_y = batch_y[:, -self.args.pred_len:, :]

                outputs_transposed = outputs.transpose(1, 2)  # Shape: (B, N, H)
                recon_outputs = torch.matmul(S_Phi_C, outputs_transposed)  # Shape: (B, N, H)
                recon_outputs = recon_outputs.transpose(1, 2)  # Shape: (B, H, N)

                pred = recon_outputs
                true = batch_y

                preds.append(pred)
                trues.append(true)

        preds = np.concatenate(preds, axis=0)
        trues = np.concatenate(trues, axis=0)
        print('test shape:', preds.shape, trues.shape)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        print('test shape:', preds.shape, trues.shape)
         # result save
        folder_path = './results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)


        mae, mse, rmse, mape, mspe,smape = metric(preds, trues)
        print('mse:{}, mae:{}, rmse:{}, mape:{}, mspe:{}, smape:{}'.format(mse, mae, rmse,mape, mspe,smape))
        f = open("result_long_term_forecast.txt", 'a')
        f.write(setting + "  \n")
        f.write('mse:{}, mae:{}, dtw:{}'.format(mse, mae, dtw))
        f.write('\n')
        f.write('\n')
        f.close()

        np.save(folder_path + 'metrics.npy', np.array([mae, mse, rmse, mape, mspe]))
        np.save(folder_path + 'pred.npy', preds)
        np.save(folder_path + 'true.npy', trues)



        return



class Exp_HF_Forecast_l2_norm(Exp_Basic):
    def __init__(self, args):
        super(Exp_HF_Forecast_l2_norm, self).__init__(args)

    def _build_model(self):
        model = self.model_dict[self.args.model].Model(self.args).float()

        if self.args.use_multi_gpu and self.args.use_gpu:
            model = nn.DataParallel(model, device_ids=self.args.device_ids)
        return model


#get shuffled training data
    def _get_data_for_training(self, flag):
        # #    def __init__(self, args, root_path, flag='train', size=None,
        #          features='S', data_path='ETTh1.csv',
        #          target='OT', scale=True, timeenc=0, freq='h', seasonal_patterns=None)
        print('self.args')
        print(self.args)
        data_set, data_loader = data_provider(self.args, flag)
        return data_set, data_loader

    def _get_data_for_test(self, flag):
        # #    def __init__(self, args, root_path, flag='train', size=None,
        #          features='S', data_path='ETTh1.csv',
        #          target='OT', scale=True, timeenc=0, freq='h', seasonal_patterns=None)
        #
        original_args = copy.deepcopy(self.args)
        original_args.data='custom_test'
        data_set, data_loader = data_provider(original_args, flag)
        return data_set, data_loader

#get S matrix
    def _get_S_C_matrix(self):
        root_path=self.args.root_path
        S_path=self.args.S_path
        C_path=self.args.C_path
        S = pd.read_csv(os.path.join(root_path,S_path))
        C=pd.read_csv(os.path.join(root_path,C_path))

        return np.array(S.iloc[:,1:]),np.array(C.iloc[:,1:])

        #return torch.tensor(S.iloc[:,1:].values, dtype=torch.float32),torch.tensor(C.iloc[:,1:].values, dtype=torch.float32)



    def _select_optimizer(self):
        model_optim = optim.Adam(self.model.parameters(), lr=self.args.learning_rate)
        return model_optim

    # def _select_criterion(self):
    #     criterion = nn.MSELoss()
    #     return criterion

    def _select_criterion(self, loss_name='SMAPE'):
        if loss_name == 'MSE':
            return nn.MSELoss()
        elif loss_name == 'MAPE':
            return mape_loss()
        elif loss_name == 'MASE':
            return mase_loss()
        elif loss_name == 'SMAPE':
            return smape_loss()

    def vali(self, vali_data, vali_loader):
        total_loss = []
        self.model.eval()
         # print(test_data.shape)
        train_data, train_loader = self._get_data_for_test(flag='train')
        S,C=self._get_S_C_matrix()

        print('S-matrix')
        print(S.shape)
        with torch.no_grad():
            S_Phi_C=train_weights(train_loader,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a,self.args.regul)
            #S_Phi_C=compute_S_Phi_C_using_all_training_data(train_loader,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a)


        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(vali_loader):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float()

                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                outputs=predict_for_one_batch(batch_x,batch_y,self.args.label_len,self.args.pred_len,self.model)

                outputs = outputs[:, -self.args.pred_len:, :]
                batch_y = batch_y[:, -self.args.pred_len:, :]
                # #inverse transformation

                #reconcil
                                    #reconciliation: S*\Phi*y_{ct}
                    #reconciliation: S*\Phi*y_{ct}
                outputs_T = outputs.permute(0, 2, 1)  # Shape (B, n, H)
                    #Perform the matrix multiplications in batch using torch.matmul
                    # Now multiply S_Phi_C with batch_y_T (B, n, H)
                result= torch.matmul(S_Phi_C.unsqueeze(0).expand(outputs.size(0), -1, -1), outputs_T)
                recon_outputs=result.permute(0, 2, 1)  # Final shape: (32, 8, 57)


                pred = recon_outputs.detach().cpu()
                true = batch_y.detach().cpu()

                #loss = criterion(pred, true)
                loss=200 * torch.mean(divide_no_nan(torch.abs(recon_outputs - batch_y),torch.abs(recon_outputs.data) + torch.abs(batch_y.data)))

                total_loss.append(loss)
        total_loss = np.average(total_loss)
        self.model.train()
        return total_loss


    def train_nn(self,train_loader,vali_data,vali_loader,S_Phi_C,model_optim,path):
        early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)

        for epoch in range(self.args.epoch2):
            train_loss = []
            self.model.train()
            epoch_time = time.time()
            #compute Phi using trained model 
            #S_Phi_C=compute_S_Phi_C_using_all_training_data(train_loader_1,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a)


            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
                #iter_count += 1
                model_optim.zero_grad()
                #batch_x: shape(b,seq_len,m)
                batch_x = batch_x.float().to(self.device)
                #batch_x: shape(b,lab_len+pre_len,m)
                batch_y = batch_y.float().to(self.device)


                outputs=predict_for_one_batch(batch_x,batch_y,self.args.label_len,self.args.pred_len,self.model)

                # encoder - decoder

                print('batch_x')
                print(batch_x.shape)

                outputs = outputs[:, -self.args.pred_len:, :]
                    #shape(B,H,n)
                batch_y = batch_y[:, -self.args.pred_len:, :]
                shape=outputs.shape
                #do the reconcilation
                print('batch_y_shape')
                print(batch_y.shape)
                print('output-shape')
                print(outputs.shape)

                # Avoid in-place operation by creating a new tensor for reconciled outputs
                outputs_transposed = outputs.transpose(1, 2)  # Shape: (B, N, H)
                recon_outputs = torch.matmul(S_Phi_C, outputs_transposed)  # Shape: (B, N, H)
                recon_outputs = recon_outputs.transpose(1, 2)  # Shape: (B, H, N)

                print('recon_outputs')
                print(recon_outputs.shape)

                loss=200 * torch.mean(divide_no_nan(torch.abs(recon_outputs - batch_y),torch.abs(recon_outputs.data) + torch.abs(batch_y.data)))
                #loss = torch.mean((recon_outputs - batch_y) ** 2)

                print('second-stage-loss')
                print(loss)
                    #loss = criterion(recon_outputs, batch_y)
                train_loss.append(loss.item())

                loss.backward()
                model_optim.step()

            print("second-stage-Epoch: {} cost time: {}".format(epoch + 1, time.time() - epoch_time))
            train_loss = np.average(train_loss)


            vali_loss = self.vali(vali_data, vali_loader)
            #test_loss = self.vali(test_data, test_loader, criterion)

            print("Epoch: {0} | Train Loss: {1:.7f} Vali Loss: {2:.7f}".format(epoch + 1, train_loss, vali_loss))
            early_stopping(vali_loss, self.model, path)
            if early_stopping.early_stop:
                print("Early stopping")
                break
            #adjust_learning_rate(model_optim, epoch + 1, self.args)

        #vali_loss = self.vali(vali_data_1, vali_loader_1, criterion)

        best_model_path = path + '/' + 'checkpoint.pth'
        self.model.load_state_dict(torch.load(best_model_path))

        return self.model,vali_loss


    def train_for_first_stage(self,train_loader,model_optim):
                # 随机抽取 10% 的索引
        # 获取所有批次数据
        #for epoch in range(self.args.train_epochs):
        for epoch in range(self.args.epoch1):
        #for epoch in range(0):
            #iter_count = 0
            train_loss = []

            self.model.train()
            epoch_time = time.time()

            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(train_loader):
            #for batch_x, batch_y, batch_x_mark, batch_y_mark in select_batches:
                #iter_count += 1
                model_optim.zero_grad()
                #batch_x: shape(b,seq_len,m)
                batch_x = batch_x.float().to(self.device)
                #batch_x: shape(b,lab_len+pre_len,m)
                batch_y = batch_y.float().to(self.device)

                # decoder input
                #dec_inp: (b,pred_len,m)
                dec_inp = torch.zeros_like(batch_y[:, -self.args.pred_len:, :]).float()
                #dec_inp: (b,label_len+pred_len,m)
                dec_inp = torch.cat([batch_y[:, :self.args.label_len, :], dec_inp], dim=1).float().to(self.device)


                print('batch_x')
                print(batch_x.shape)
                print('batch_x_mark')
                print(batch_x_mark.shape)
                print('dec_inp')
                print(dec_inp.shape)
                outputs = self.model(batch_x, None, dec_inp, None)
                print('output-shape')
                print(outputs.shape)
                print('batch_y')
                print(batch_y.shape)

                outputs = outputs[:, -self.args.pred_len:, :]
                    #shape(B,H,n)
                batch_y = batch_y[:, -self.args.pred_len:, :]
                batch_y_mark = batch_y_mark[:, -self.args.pred_len:,:].to(self.device)
                shape=outputs.shape
                #loss = criterion(batch_x, self.args.frequency, outputs, batch_y, batch_y_mark)
                loss=200 * torch.mean(divide_no_nan(torch.abs(outputs - batch_y),torch.abs(outputs.data) + torch.abs(batch_y.data)))
                #loss = criterion(outputs, batch_y)
                print('first-stage-loss')
                print(loss)
                    #loss = criterion(recon_outputs, batch_y)
                train_loss.append(loss.item())

                loss.backward()
                model_optim.step()

            print("first-stage-Epoch: {} cost time: {}".format(epoch + 1, time.time() - epoch_time))
            #train_loss = np.average(train_loss)

        return self.model



    def test_no_recon(self,setting):
        train_data_1, train_loader_1 = self._get_data_for_test(flag='train')
        vali_data_1, vali_loader_1 = self._get_data_for_test(flag='val')
        test_data_1, test_loader_1 = self._get_data_for_test(flag='test')


        preds=[]
        trues=[]
        all_errors = []
        for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader_1):
            batch_x = batch_x.float()
            batch_y = batch_y.float()
            # num_of_series=batch_x.shape[2]
            outputs=predict_for_one_batch(batch_x,batch_y,self.args.label_len,self.args.pred_len,self.model)
            outputs = outputs[:, -self.args.pred_len:, :] #shape(B,H,N)
            batch_y = batch_y[:, -self.args.pred_len:, :]
            shape=outputs.shape

            pred = outputs.detach().cpu().numpy()
            true = batch_y.detach().cpu().numpy()

            preds.append(pred)
            trues.append(true)



        preds = np.concatenate(preds, axis=0)
        trues = np.concatenate(trues, axis=0)
        print('test shape:', preds.shape, trues.shape)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        print('test shape:', preds.shape, trues.shape)
         # result save
        folder_path = './results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)


        mae, mse, rmse, mape, mspe,smape = metric(preds, trues)
        print('mse:{}, mae:{}, rmse:{}, mape:{}, mspe:{}, smape:{}'.format(mse, mae, rmse,mape, mspe,smape))
        # f = open("result_long_term_forecast.txt", 'a')
        # f.write(setting + "  \n")
        # f.write('mse:{}, mae:{}, dtw:{}'.format(mse, mae, dtw))
        # f.write('\n')
        # f.write('\n')
        # f.close()

        return 


    def test_two_steps(self,setting):
        S,C=self._get_S_C_matrix()
        S=torch.tensor(S).float()
        train_data_1, train_loader_1 = self._get_data_for_test(flag='train')
        vali_data_1, vali_loader_1 = self._get_data_for_test(flag='val')
        test_data_1, test_loader_1 = self._get_data_for_test(flag='test')


        preds=[]
        trues=[]
        recon_BU=[]
        recon_OLS=[]
        recon_mint=[]
        recon_partial=[]
        all_errors = []
        #OLS method free of data
        P_OLS=torch.matmul(torch.inverse(torch.matmul(S.t(), S)),S.t())
        #var-cov matrix of prediction errors of base forecasts
        var_cov_erros=cal_var_cov_errors(train_loader_1,self.args.label_len,self.args.pred_len,self.model) #Shape:(N,N)
        inv_var_cov=torch.inverse(var_cov_erros)
        inv_1=torch.inverse(torch.matmul(torch.matmul(S.t(),inv_var_cov),S))
        S_P_minT=torch.matmul(torch.matmul(S,inv_1),torch.matmul(S.t(),inv_var_cov))

        #comb_partial method
        C_comb_partial=compute_C_for_comb_partial(S)
        var_cov_erros_comb_p=torch.matmul(torch.matmul(C_comb_partial,var_cov_erros),C_comb_partial.t())
        Phi_partial=compute_Phi_comb_partial(S, var_cov_erros_comb_p)
        S_Phi_C_partial=torch.matmul(torch.matmul(S,Phi_partial),C_comb_partial)


        var_cov_y_c_partial=torch.matmul
        for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader_1):
            batch_x = batch_x.float()
            batch_y = batch_y.float()
            # num_of_series=batch_x.shape[2]
            outputs=predict_for_one_batch(batch_x,batch_y,self.args.label_len,self.args.pred_len,self.model)
            outputs = outputs[:, -self.args.pred_len:, :] #shape(B,H,N)
            batch_y = batch_y[:, -self.args.pred_len:, :]
            shape=outputs.shape

            outputs_transposed = outputs.transpose(1, 2)  # Shape: (B, N, H)

            #bottom-up method
            recon_preds_BU = torch.matmul(S, outputs_transposed[:,-self.args.n_b:,:])  # Shape: (B, N, H)
            recon_preds_BU = recon_preds_BU.transpose(1, 2)  # Shape: (B, H, N)
            recon_BU.append(recon_preds_BU.detach().cpu().numpy())

            #ols method
            recon_preds_OLS=torch.matmul(torch.matmul(S,P_OLS),outputs_transposed)
            recon_preds_OLS = recon_preds_OLS.transpose(1, 2)  # Shape: (B, H, N)
            recon_OLS.append(recon_preds_OLS.detach().cpu().numpy())


            #minT method
            recon_preds_minT=torch.matmul(S_P_minT,outputs_transposed)
            recon_preds_minT = recon_preds_minT.transpose(1, 2)  # Shape: (B, H, N)
            recon_mint.append(recon_preds_minT.detach().cpu().numpy())

            #comb_partial method
            recon_preds_partial=torch.matmul(S_Phi_C_partial,outputs_transposed)
            recon_preds_partial = recon_preds_partial.transpose(1, 2)  # Shape: (B, H, N)
            recon_partial.append(recon_preds_partial.detach().cpu().numpy())



            pred = outputs.detach().cpu().numpy()
            true = batch_y.detach().cpu().numpy()

            preds.append(pred)
            trues.append(true)



        preds = np.concatenate(preds, axis=0)
        trues = np.concatenate(trues, axis=0)
        print('test shape:', preds.shape, trues.shape)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        print('test shape:', preds.shape, trues.shape)
         # result save
        folder_path = './results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)


        mae, mse, rmse, mape, mspe,smape = metric(preds, trues)
        print('base-mse:{}, mae:{}, rmse:{}, mape:{}, mspe:{}, smape:{}'.format(mse, mae, rmse,mape, mspe,smape))
        # f = open("result_long_term_forecast.txt", 'a')
        # f.write(setting + "  \n")
        # f.write('mse:{}, mae:{}, dtw:{}'.format(mse, mae, dtw))
        # f.write('\n')
        # f.write('\n')
        # f.close()

        recon_BU = np.concatenate(recon_BU, axis=0)
        print('test shape:', recon_BU.shape, trues.shape)
        recon_BU = recon_BU.reshape(-1, recon_BU.shape[-2], recon_BU.shape[-1])
        mae, mse, rmse, mape, mspe,smape = metric(recon_BU, trues)
        print('bottom-up-mse:{}, mae:{}, rmse:{}, mape:{}, mspe:{}, smape:{}'.format(mse, mae, rmse,mape, mspe,smape))


        recon_OLS = np.concatenate(recon_OLS, axis=0)
        print('test shape:', recon_OLS.shape, trues.shape)
        recon_OLS = recon_OLS.reshape(-1, recon_OLS.shape[-2], recon_OLS.shape[-1])
        mae, mse, rmse, mape, mspe,smape = metric(recon_OLS, trues)
        print('OLS-mse:{}, mae:{}, rmse:{}, mape:{}, mspe:{}, smape:{}'.format(mse, mae, rmse,mape, mspe,smape))


        recon_mint = np.concatenate(recon_mint, axis=0)
        print('test shape:', recon_mint.shape, trues.shape)
        recon_mint = recon_mint.reshape(-1, recon_mint.shape[-2], recon_mint.shape[-1])
        mae, mse, rmse, mape, mspe,smape = metric(recon_mint, trues)
        print('minT-mse:{}, mae:{}, rmse:{}, mape:{}, mspe:{}, smape:{}'.format(mse, mae, rmse,mape, mspe,smape))


        recon_partial = np.concatenate(recon_partial, axis=0)
        print('test shape:', recon_partial.shape, trues.shape)
        recon_partial = recon_partial.reshape(-1, recon_partial.shape[-2], recon_partial.shape[-1])
        mae, mse, rmse, mape, mspe,smape = metric(recon_partial, trues)
        print('comb-partial-mse:{}, mae:{}, rmse:{}, mape:{}, mspe:{}, smape:{}'.format(mse, mae, rmse,mape, mspe,smape))


        return 



    def train(self, setting):
        #get batch data
        #
        train_data, train_loader = self._get_data_for_training(flag='train')
        S,C=self._get_S_C_matrix()
        print('S-matrix')
        print(S.shape)
        print('C-matrix')
        print(C.shape)

        path = os.path.join(self.args.checkpoints, setting)
        if not os.path.exists(path):
            os.makedirs(path)

        time_now = time.time()

        #train_steps = len(train_loader)
        #early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)

        model_optim = self._select_optimizer()
        criterion = self._select_criterion()


        #first stage, smape training without reconcilation
        # 随机抽取 10% 的索引
        # 获取所有批次数据
        #all_batches = list(train_loader)
        

        #first stage: train NN without reconcilation using SMAPE
        #self.model=train_for_first_stage(self,train_loader,model_optim)
        #train_for_first_stage(self,train_loader,model_optim)
        if self.args.rate!=1.0:
            all_batches = list(train_loader)
            train_loader = random.sample(all_batches, int(len(all_batches) * self.args.rate)) # 随机选择rate(比如10%)的批次， for efficiency
        
        

        self.model=self.train_for_first_stage(train_loader,model_optim)
        #self.model=self.train_for_first_stage(select_batches,model_optim)


        #compute accuracy on test data using the model trained at first stage

        #self.test_no_recon(setting)
        self.test_two_steps(setting)
        #test recon
        if self.args.two_step:
            sys.exit("Stopping execution at this point")


        train_data_1, train_loader_1 = self._get_data_for_test(flag='train')
        vali_data_1, vali_loader_1 = self._get_data_for_test(flag='val')
        test_data_1, test_loader_1 = self._get_data_for_test(flag='test')

        #second stage: alternate training for reconcilation


        #early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)

        for i in range(5):
            print('alternate_time')
            print(i+1)
                #compute Phi using trained model 
            #S_Phi_C=compute_S_Phi_C_using_all_training_data(train_loader_1,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a)
            S_Phi_C=train_weights(train_loader_1,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a,self.args.regul)
            #S_Phi_C=compute_S_Phi_C_using_all_training_data_l2_norm(train_loader_1,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a,lamda)
            self.model,vali_loss=self.train_nn(train_loader_1,vali_data_1,vali_loader_1,S_Phi_C,model_optim,path)

            print(f"alidation loss {vali_loss:.6f}")

        return self.model

    def test(self, setting, test=0):
        #test_data is an instance of cunstom_dataset()
        preds = []
        trues = []

        train_data_1, train_loader_1 = self._get_data_for_test(flag='train')
        #vali_data_1, vali_loader_1 = self._get_data_for_test(flag='val')
        test_data_1, test_loader_1 = self._get_data_for_test(flag='test')
        S,C=self._get_S_C_matrix()
        print('S-matrix')
        print(S.shape)
        print('C-matrix')
        print(C.shape)
        # print('test_data_shape')
        # print(test_data.shape)
        if test:
            print('loading model')
            self.model.load_state_dict(torch.load(os.path.join('./checkpoints/' + setting, 'checkpoint.pth')))

        #estimate var of each component series


        preds = []
        trues = []
        folder_path = './test_results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        self.model.eval()

        with torch.no_grad():
            # Initialize a container to accumulate errors across batches
            S_Phi_C=train_weights(train_loader_1,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a,self.args.regul)
            #S_Phi_C=compute_S_Phi_C_using_all_training_data(train_loader_1,self.args.label_len,self.args.pred_len,self.model,S,C,self.args.n_b,self.args.n_a)


        with torch.no_grad():
            for i, (batch_x, batch_y, batch_x_mark, batch_y_mark) in enumerate(test_loader_1):
                batch_x = batch_x.float().to(self.device)
                batch_y = batch_y.float().to(self.device)

                batch_x_mark = batch_x_mark.float().to(self.device)
                batch_y_mark = batch_y_mark.float().to(self.device)

                outputs=predict_for_one_batch(batch_x,batch_y,self.args.label_len,self.args.pred_len,self.model)

                outputs = outputs[:, -self.args.pred_len:, :]
                batch_y = batch_y[:, -self.args.pred_len:, :]

                outputs_transposed = outputs.transpose(1, 2)  # Shape: (B, N, H)
                recon_outputs = torch.matmul(S_Phi_C, outputs_transposed)  # Shape: (B, N, H)
                recon_outputs = recon_outputs.transpose(1, 2)  # Shape: (B, H, N)

                pred = recon_outputs
                true = batch_y

                preds.append(pred)
                trues.append(true)

        preds = np.concatenate(preds, axis=0)
        trues = np.concatenate(trues, axis=0)
        print('test shape:', preds.shape, trues.shape)
        preds = preds.reshape(-1, preds.shape[-2], preds.shape[-1])
        trues = trues.reshape(-1, trues.shape[-2], trues.shape[-1])
        print('test shape:', preds.shape, trues.shape)
         # result save
        folder_path = './results/' + setting + '/'
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)


        mae, mse, rmse, mape, mspe,smape = metric(preds, trues)
        print('mse:{}, mae:{}, rmse:{}, mape:{}, mspe:{}, smape:{}'.format(mse, mae, rmse,mape, mspe,smape))
        f = open("result_long_term_forecast.txt", 'a')
        f.write(setting + "  \n")
        f.write('mse:{}, mae:{}, dtw:{}'.format(mse, mae, dtw))
        f.write('\n')
        f.write('\n')
        f.close()

        np.save(folder_path + 'metrics.npy', np.array([mae, mse, rmse, mape, mspe]))
        np.save(folder_path + 'pred.npy', preds)
        np.save(folder_path + 'true.npy', trues)



        return


