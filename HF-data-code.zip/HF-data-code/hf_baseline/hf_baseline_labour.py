import mxnet as mx
import numpy as np
import pandas as pd
from gluonts.dataset.hierarchical import HierarchicalTimeSeries
from gluonts.mx.model.deepvar_hierarchical import DeepVARHierarchicalEstimator
from gluonts.mx.trainer import Trainer
from seed import set_global_seed
from joblib import Parallel, delayed

# Set global seed for reproducibility
# set_global_seed(2)

# # Set the seed for MXNet (DeepVAR uses MXNet under the hood)
# mx.random.seed(2)
# np.random.seed(2)

# Ensure deterministic behavior on GPUs (if using GPU)
# Uncomment the following lines if you are using a GPU
# mx.random.seed(2)
# os.environ['MXNET_CUDNN_AUTOTUNE_DEFAULT'] = '0'
# os.environ['MXNET_CUDNN_BENCHMARK'] = '0'

def hierarchical_forecast(train_ts_bottom_series: pd.DataFrame, 
                          S: np.ndarray, 
                          pred_len: int, 
                          epochs: int = 10):
    """
    Generate hierarchical forecasts using DeepVARHierarchicalEstimator.
    
    Parameters:
        train_ts_bottom_series (pd.DataFrame): Bottom-level training time series as a DataFrame with `PeriodIndex`.
        S (np.ndarray): Aggregation matrix.
        pred_len (int): Number of steps to forecast.
        epochs (int): Number of epochs for training the model (default=10).
    
    Returns:
        np.ndarray: Forecasted means with shape (pred_len, N).
    """
    # Create HierarchicalTimeSeries object
    hts = HierarchicalTimeSeries(
        ts_at_bottom_level=train_ts_bottom_series,
        S=S,
    )
    
    # Convert to dataset
    dataset = hts.to_dataset()
    
    # Initialize estimator
    estimator = DeepVARHierarchicalEstimator(
        freq=hts.freq,
        prediction_length=pred_len,
        trainer=Trainer(epochs=epochs),
        S=S,
    )
    
    # Train the model
    set_global_seed(2)

# Set the seed for MXNet (DeepVAR uses MXNet under the hood)
    mx.random.seed(2)
    predictor = estimator.train(dataset)
    
    # Generate forecasts
    forecast_it = predictor.predict(dataset)
    forecasts = next(forecast_it)  # Only one forecast object in the iterator
    
    # Extract forecast means
    forecast_means = forecasts.mean  # Shape: (prediction_length, N)
    
    return forecast_means

def compute_metrics_and_forecast(i, data, ts_at_bottom_level, S, T, h):
    """Calculate forecast and metrics for each iteration"""
    print(f"Processing step {i + 1} / {s}")
    
    # Training and testing data
    train = data.iloc[i:(T + i), :]
    test = data.iloc[(T + i):(T + i + h), :]

    # Generate forecast using DeepVAR
    forecasts = hierarchical_forecast(ts_at_bottom_level.iloc[i:(i+T), :], S, h)
    
    # Calculate metrics
    mse = np.mean((test - forecasts) ** 2)
    mae = np.mean(np.abs(test - forecasts))
    smape = 200 * np.mean(np.abs(test - forecasts) / (np.abs(test) + np.abs(forecasts)))

    return forecasts, mse, mae, smape

# Reading data and setup
dataset_name = "Labour"
h = 8
freq = 12

# File paths
path = f"./hfdatasets/{dataset_name}"
file_d = f"{path}/data.csv"
file_S = f"{path}/agg_mat.csv"

# Read data
data = pd.read_csv(file_d).iloc[:,1:]  # Remove first column
len1 = data.shape[0]
data.index=pd.date_range(start="1978-02-01", periods=len1, freq="M")
data = data.to_period()

# Split data for testing and training
test_len = int(len1 * 0.2)
T = len1 - test_len
s = test_len - h + 1

# Load aggregation matrix S
S = pd.read_csv(file_S).iloc[:,1:].values 
n, n_b = S.shape

# Set up the bottom-level time series
ts_at_bottom_level = data.iloc[:, -n_b:]

# Parallelize the loop to compute forecasts and metrics
results = Parallel(n_jobs=-1)(delayed(compute_metrics_and_forecast)(
    i, data, ts_at_bottom_level, S, T, h
) for i in range(s))

# Extract forecasts and metrics from results
forecasts_tensor = np.array([result[0] for result in results])
mae_all = [result[2] for result in results]
mse_all = [result[1] for result in results]
smape_all = [result[3] for result in results]

# Print evaluation metrics
print('mae:', np.mean(mae_all))
print('mse:', np.mean(mse_all))
print('smape:', np.mean(smape_all))

# Optionally, save the forecasts tensor to a file
np.save(dataset_name+"_forecasts.npy", forecasts_tensor)
