export CUDA_VISIBLE_DEVICES=7

model_name=TimesNet

python -u run.py \
  --task_name HF_forecast_l2_norm \
  --is_training 1 \
  --root_path ./dataset/LabourNew/ \
  --data_path data.csv \
  --model_id LabourNew_16_8_l2norm \
  --model $model_name \
  --data custom_train \
  --features M \
  --seq_len 24 \
  --label_len 12 \
  --pred_len 8 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 1 \
  --dec_in 1 \
  --c_out 1 \
  --d_model 32 \
  --d_ff 32 \
  --top_k 5 \
  --des 'Exp' \
  --itr 1 \
  --train_epochs 10 \
  --S_path agg_mat.csv \
  --C_path LabourNew_C.csv \
  --n_a 15 \
  --n 63 \
  --n_b 48 \
  --history_size 1 \
  --frequency 12 \
  --regul L2_norm \
