export CUDA_VISIBLE_DEVICES=4

model_name=Transformer

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/Labour/ \
  --data_path Labour.csv \
  --model_id Labour_96_48 \
  --model $model_name \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 8 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 57 \
  --dec_in 57 \
  --c_out 57 \
  --des 'Exp' \
  --itr 1 \
  --train_epochs 5 \
  --S_path agg_mat.csv \
  --C_path Labour_C.csv \
  --n_a 25 \
  --n 57 \
  --n_b 32 
