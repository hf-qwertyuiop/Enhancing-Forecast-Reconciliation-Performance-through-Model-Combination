export CUDA_VISIBLE_DEVICES=7

model_name=TimesNet

python -u run.py \
  --task_name long_term_forecast \
  --is_training 1 \
  --root_path ./dataset/Traffic/ \
  --data_path data.csv \
  --model_id Traffic_36_8 \
  --model $model_name \
  --data custom \
  --features M \
  --seq_len 96 \
  --label_len 48 \
  --pred_len 1 \
  --e_layers 2 \
  --d_layers 1 \
  --factor 3 \
  --enc_in 207 \
  --dec_in 207 \
  --c_out 207 \
  --d_model 100 \
  --d_ff 100 \
  --top_k 5 \
  --des 'Exp' \
  --itr 1 \
  --train_epochs 5 \
  --S_path agg_mat.csv \
  --C_path Traffic_C.csv \
  --n_a 7 \
  --n 207 \
  --n_b 200 \


#exp1
  # --d_model 64 \
  # --d_ff 64 \

